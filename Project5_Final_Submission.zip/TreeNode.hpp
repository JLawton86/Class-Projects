//hpp file
/***************************************************
 * FILE: TreeNode.hpp                              *
 * AUTHOR: Jacob Lawton                            *
 * DATE: 3/21/2022                                 *
 * Platform Developed on: Linux                    *
 * PURPOSE: Header file for TreeNode class         *
 *   This class describes a Binary Tree and Nodes  *
 *   in that tree.                                 *
 ***************************************************/
#ifndef _TREE_NODE_HPP_
#define _TREE_NODE_HPP_

#include <iostream>
#include <string>
#include "CarRating.hpp"

using namespace std;
class TreeNode
{
private:
  CarRating *_data;

  TreeNode *_parent;
  TreeNode *_left;
  TreeNode *_right;
  
public:
  TreeNode(const CarRating &value):
    _data(new CarRating (value)), _parent(), _left(), _right()  {} 

  const CarRating* data() const {return _data;}
  CarRating* & data()  {return _data;} // use with EXTREME caution!

  const TreeNode* parent() const {return _parent;}
  TreeNode* & parent()  {return _parent;}

  const TreeNode* left() const {return _left;}
  TreeNode* & left() {return _left;}
  
  const TreeNode* right() const {return _right;}
  TreeNode* & right() {return _right;}

  bool isLeaf() const;
  int depth() const;

  friend std::ostream& operator<<(std::ostream &os, const TreeNode &tn);
};

#endif
