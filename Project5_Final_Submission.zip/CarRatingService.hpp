//hpp file
/***************************************************
 * FILE: CarRatingService.hpp                      *
 * AUTHOR: Jacob Lawton                            *
 * DATE: 3/21/2022                                 *
 * Platform Developed on: Linux                    *
 * PURPOSE: Header file for CarRatingService class *
 *   This class describes a car and a rating       *
 *   for that car.                                 *
 ***************************************************/
#ifndef _CAR_RATING_Service_HPP_
#define _CAR_RATING_Service_HPP_

#include <iostream>
#include <string>
#include "CarRating.hpp"
#include "TreeNode.hpp"

using namespace std;

class CarRatingService {
private:
	int _numCars; //number of different types of cars in CarRatingService
	int _curr; // current amount of cars in the collection
	TreeNode *_root;


	void printHelper(ostream &, const TreeNode *node) const;
	void clear(TreeNode *node);
public:
	// default constructor
	CarRatingService() :
			_numCars(0), _curr(0), _root(NULL) {
	}

	//method for input stream
	CarRatingService(istream &_input);

	//accessor methods
	int numCars() const {
		return _numCars;
	}
	void clear();
	
	//void CarRatingService::remove(CarRating toBeRemoved);
	//void CarRatingService::deleteNode(CarRating toBeRemoved, TreeNode *&nodePtr);
	//void CarRatingService::makeDeletion(TreeNode *&nodePtr);
	
	//bool CarRatingService searchNode(CarRating num);

	void printMake(string); //need to code
	void printModel(string); //need to code
	void printYear(int); //need to code

	TreeNode* recursiveInsert(TreeNode *intoSubTree, TreeNode *newRating);

	//overloaded operator for printing
	ostream& print(ostream &toStream) const;

	//overloads operator for output
	friend ostream& operator<<(ostream &os, const CarRatingService &crs);

	//overloading first += operator
	const CarRatingService& operator+=(CarRating const &newRating);
	const CarRatingService& operator+=(CarRatingService const &newRating); //need to code

	const CarRatingService& operator-=(CarRating const &newRating); // need to code
};
#endif
