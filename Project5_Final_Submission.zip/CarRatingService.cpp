//cpp file
/************************************************
 * FILE: CarRatingService.cpp                   *
 * AUTHOR: Jacob Lawton                         *
 * DATE: 3/21/2022                              *
 * Platform Developed on: Linux                 *
 * PURPOSE: Implements CarRatingService class   *
 ************************************************/
#include "CarRatingService.hpp"

using namespace std;

// gets information from the input stream
CarRatingService::CarRatingService(istream &_input) {
	int x = 0;

	//initializes instance variables
	CarRating nextRating;
	_numCars = 0;
	_curr = 0;
	_root = 0;

	// takes the car's information and stores it in a node
	while (_input >> nextRating) {
		x++;
		_numCars = x;
		_curr++;

		(*this) += nextRating;
	}
}
// clears the tree of nodes
void CarRatingService::clear(TreeNode *node) {
	if(node == 0) {
		return;
	}
	clear(node->left());
	clear(node->right());
	delete node;

}
// clears the collection of car ratings
void CarRatingService::clear() {
	_numCars = 0;
	_root = 0;
}
// puts the returned car rating information into the output stream
void CarRatingService::printHelper(ostream &os, const TreeNode *node) const {
	if(node == 0) return;
	printHelper(os, node->left());
	node->data()->print(os);
	os << endl;
	printHelper(os, node->right());
}

//returns the car rating information to be printed
ostream& CarRatingService::print(ostream &toStream) const {
	printHelper(toStream, _root);
	return toStream;
}

//prints the car rating information
ostream& operator<<(ostream &os, const CarRatingService &crs) {
	return crs.print(os);
}

//finds where to insert the new node
TreeNode*
CarRatingService::recursiveInsert(TreeNode *intoSubTree, TreeNode *newRating) {
// should I insert in left subtree? 
	if(intoSubTree == 0) {

		return newRating;
	}
	if ((newRating->data()->make()) < (intoSubTree->data()->make())
			|| (newRating->data()->model()) < (intoSubTree->data()->model())
			|| (newRating->data()->year()) < (intoSubTree->data()->year())) {
		// insert newNode into left subtree and update this node's left pointer
		intoSubTree->left() = recursiveInsert(intoSubTree->left(), newRating);

		// update modified left child's parent properly.
		intoSubTree->left()->parent() = intoSubTree;
	} else if ((newRating->data()->make()) > (intoSubTree->data()->make())
			|| (newRating->data()->model()) > (intoSubTree->data()->model())
			|| (newRating->data()->year()) > (intoSubTree->data()->year())) {
		// insert newNode into right subtree and update this node's right pointer
		intoSubTree->right() = recursiveInsert(intoSubTree->right(), newRating);

		// update modified right child's parent properly.
		intoSubTree->right()->parent() = intoSubTree;
	} else // equal, so node is already there!!!
	{
		intoSubTree->data()->addNewRating(newRating->data()->rating());
	}

	// return updated subtree
	return intoSubTree;
}
//overloads the += operator to add more car ratings to the list
const CarRatingService&
CarRatingService::operator+=(const CarRating &newRating) {
	TreeNode *nodeToInsert = new TreeNode(newRating);
	_root = recursiveInsert(_root, nodeToInsert);
	return *this;
}
//should add all car ratings corresponding to the parameter to this collection (not done)
const CarRatingService& 
CarRatingService::operator+=(CarRatingService const &newRating) //need to code
{
	return *this;	
}
//should remove car rating corresponding to the parameter (not done)
const CarRatingService& 
CarRatingService::operator-=(CarRating const &newRating) // need to code
{
	return *this;
}
//tried to make functions that delete a certain node unable to finish because of time
/*
void CarRatingService::remove(CarRating toBeRemoved)
{
	deleteNode(toBeRemoved, _root);
}
void CarRatingService::deleteNode(CarRating toBeRemoved, TreeNode *&nodePtr)
{
	if(num < nodePtr->data())
		deleteNode(toBeRemoved, nodePtr->left);
	else if (num > nodePtr->data())
		deleteNode(toBeRemoved, nodePtr->right);
	else
		return -=(nodePtr);	
}
void CarRatingService::makeDeletion(TreeNode *&nodePtr)
{
	TreeNode *tempNodePtr = 0
	
	if(nodePtr == 0)
		cout << "Cannot delete empty node." << endl;
	else if (nodePtr->right == 0)
	{
		tempNodePtr = nodePtr;
		nodePtr = nodePtr->left; //left child
		delete tempNodePtr;
	}
	else if (nodePtr->left == 0)
	{
		tempNodePtr = nodePtr;
		nodePtr = nodePtr->right; //right child
		delete tempNodePtr;
	}
	// if node has two children
	else
	{
		tempNodePtr = nodePtr->right;
		while(tempNodePtr->left)
			tempNodePtr = tempNodePtr->left
		tempNodePtr->left = nodePtr->left;
		tempNodePtr = nodePtr
		nodePtr = nodePtr->right;
		delete tempNodePtr;
	}
}	

*/
//Tried to make a function that searches the tree unable to finish because of time
/*bool CarRatingService
CarRatingService::searchNode(CarRating num)
{
	TreeNode *nodePtr = _root;
	
	while (nodePtr)
	{
		if(nodePtr->data() == num)
			return true;
		else if (num < nodePtr->data())
			nodePtr = nodePtr->left();
		else
			nodePtr = nodePtr->right();
	}
	return false;
}
*/
//should print same make as the value passed in
void printMake(string sameMake) //need to code
{
	
	cout << sameMake;
} 
//should print same model as the value passed in	
void printModel(string sameModel) //need to code
{
	cout << sameModel;
}
//should print same year as the value passed in
void printYear(int sameYear) //need to code
{
	cout << sameYear;
}
