/*
Author: Jacob Lawton
Developed On Windows
Project Start Date: 2/3/22
Project End Date: 2/15/22
*/
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

//variable used to store file name
string fileName;

//variables that takes the number of rows and columns from an input file
int rows;
int cols;
int startRows;
int startCols;
int endRows;
int endCols;
int g;
int y;

//puts variable into myInputFile so it can be read
ifstream myInputFile;

//creates a two dimensional array called maze that is 200*200 in size
char maze[201][201];

bool canGoUp(int row, int col);
bool canGoRight(int row, int col);
bool canGoDown(int row, int col);
bool canGoLeft(int row, int col);

void initMaze()
{
	//prompts user for file name
	cout << "What file would you like to use? ";

	cin >> fileName;

	//opens the file
	myInputFile.open(fileName);

	//tells user if file works
	if (myInputFile.fail())
	{
		cout << "error";
	}
}
void printMaze()
{
	//takes the first six values from the input file and sets them as the amount of rows and columns as well as the starting and ending positions
	myInputFile >> rows >> cols >> startRows >> startCols >> endRows >> endCols;
	cout << rows << " ";
	cout << cols << endl;
	cout << startRows << " ";
	cout << startCols << endl;
	cout << endRows << " ";
	cout << endCols << endl << endl;
	
	//reads in the maze from the inputfile
	for (g = 0; g < rows; g++)
	{
		for (y = 0; y < cols; y++)
		{
			myInputFile >> maze[g][y];
		}
	}

	//prints maze
	for (g = 0; g < rows; g++)
	{
		for (y = 0; y < cols; y++)
		{
			cout << maze[g][y];
		}
		cout << endl;
	}
}
bool solveMaze(int row, int col)
{	
	//if player reaches end of the maze stop
	if (col == endCols && row == endRows)
	{
		cout << endl << "You got to the end of the maze!" << endl;
		return true;
	}
	//checks if start location is on the board
	if ((row > 200 || row < 0) || (col > 200 || col < 0))
	{
		return false;
	}
	//checks to make sure start location isn't on a wall 
	if (maze[row][col] == '#')
	{
		return false;
	}
	maze[row][col] = '*';
	//sends maze position to make sure it can move up
	if (canGoUp(row, col))
	{
		//if it can it loops back to go through the process again(same thing for the other directions)
		if (solveMaze(row-1, col))
		{
			return true;
		}
	}
	//sends maze position to make sure it can move right
	if (canGoRight(row, col))
	{
		if (solveMaze(row, col+1))
		{
			return true;
		}
	}
	//sends maze position to make sure it can move down
	if (canGoDown(row, col))
	{
		if (solveMaze(row+1, col))
		{
			return true;
		}
	}
	//sends maze position to make sure it can move left
	if (canGoLeft(row, col))
	{
		if (solveMaze(row, col-1))
		{
			return true;
		}
	}
	//Don't know why this isn't working
	/* if (!canGoUp(row, col) && !canGoRight(row, col) && !canGoDown(row, col) && !canGoLeft(row, col))
	{
		cout << "No Solution!" << endl;
	} */
	else
	{
		maze[row][col] = 'B';
		return false;
	}
}
bool canGoUp(int row, int col)
{
	//checks if maze goes up 1
	if (maze[row - 1][col] == '+')
	{
		maze[row - 1][col] = '*';
		row--;
		return true;
	}
	else if (maze[row - 1][col] == 'B')
	{
		return false;
	}
	else
	{
		return false;
	}
}
bool canGoRight(int row, int col)
{
	//checks if maze goes right 1
	if (maze[row][col + 1] == '+')
	{
		maze[row][col + 1] = '*';
		col++;
		return true;
	}
	else if (maze[row][col + 1] == 'B')
	{
		return false;
	}
	else
	{
		return false;
	}
}
bool canGoDown(int row, int col)
{
	//checks if maze goes down 1
	if (maze[row + 1][col] == '+')
	{
		maze[row + 1][col] = '*';
		row++;
		return true;
	}
	else if (maze[row + 1][col] == 'B')
	{
		return false;
	}
	else
	{
		return false;
	}
}
bool canGoLeft(int row, int col)
{
	//checks if maze goes left 1
	if (maze[row][col - 1] == '+')
	{
		maze[row][col - 1] = '*';
		col--;
		return true;
	}
	else if (maze[row][col - 1] == 'B')
	{
		return false;
	}
	else
	{
		return false;
	}
}

int main(int numArgs, char* argv[])
{
	initMaze();
	printMaze();
	solveMaze(startRows, startCols);
	printMaze();
}