#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main(int numArgs, char* argv[])
{
	//variable used to store file name
	string fileName;

	//variables that takes the number of rows and columns from an input file
	int rows;
	int cols;
	int g;
	int y;

	int x = 0;
	bool answer = false;

	//creates a two dimensional array called board that is 100*100 in size
	char board[101][101];

	//prompts user for file name
	cout << "What file would you like to use?" << endl;

	cin >> fileName;

	//puts variable into myInputFile so it can be read
	ifstream myInputFile;

	//opens the file
	myInputFile.open(fileName);

	//tells user if file works
	if (myInputFile.fail())
	{
		cout << "error";
	}

	//takes the first two values from the input file and sets them as the rows and columns
	myInputFile >> rows >> cols;
		
	//prints out the chess board
	for (g = 0; g < rows; g++)
	{
		for (y = 0; y < cols; y++)
		{
			myInputFile >> board[g][y];
			cout << board[g][y]; 
		}
		cout << endl;
	}
	//checks when an input is k if there is another k around it 
	for (g = 0; g < rows; g++)
	{
		for (y = 0; y < cols; y++)
		{
			if (board[g][y] == 'k' && (board[g - 1][y - 2] == 'k' || board[g + 1][y - 2] == 'k' || board[g - 2][y - 1] == 'k' || board[g + 2][y - 1] == 'k'))
			{
				answer = true;
			}
		}
	}
	//prints out if the knights can attack each other or not
	if (answer)
	{
		cout << "At least one knight is attacking another!";
	}
	else
	{
		cout << "No knights are attacking each other" << endl;
	}
}