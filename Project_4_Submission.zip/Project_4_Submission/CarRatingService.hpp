//hpp file
/***************************************************
 * FILE: CarRatingService.hpp                      *
 * AUTHOR: Jacob Lawton                            *
 * DATE: 3/21/2022                                 *
 * Platform Developed on: Linux                    *
 * PURPOSE: Header file for CarRatingService class *
 *   This class describes a car and a rating       *
 *   for that car.                                 *
 ***************************************************/
#ifndef _CAR_RATING_Service_HPP_
#define _CAR_RATING_Service_HPP_

#include <iostream>
#include <string>
#include "CarRating.hpp"
#include "CarNode.hpp"

using namespace std;

class CarRatingService
{
private:
    int _numCars; //number of different types of cars in CarRatingService
    int _curr; // current amount of cars in the collection
    CarNode *_head;
    CarNode *_tail;
public:
    // default constructor
    CarRatingService() :
        _numCars(0), _curr(0), _head(NULL), _tail(NULL) {}
        
  	void addFront(const CarRating &newData);
  	void append(const CarRating &newData); //add at end of list
  	void insertBefore(CarNode *here, const CarRating &newData);
  	void insertAfter(CarNode *here, const CarRating &newData);

	bool isEmpty() const {return _head==NULL;}

    //method for input stream
    CarRatingService(istream& _input);

        //accessor methods
        int numCars() const { return _numCars;}
        void clear();

    //overloaded operator for printing
    ostream& print(ostream& toStream) const;

    //overloads operator for output
    friend ostream& operator<<(ostream& os, const CarRatingService& crs);

    //overloading first += operator
    const CarRatingService& operator+=(CarRating const &newRating);
    
    //accessor methods that find the tail of the list and the previous node in the list
    CarNode* findTail(){return _tail;}
    CarNode* findPrev();
    
    

};
#endif
