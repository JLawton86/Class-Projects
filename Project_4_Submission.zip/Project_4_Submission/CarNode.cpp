#include "CarNode.hpp"

using namespace std;

ostream& operator<<(ostream &os, const CarNode &ln)
{
  os << ln._data; // << " : " << ln._next;

  return os;
}
