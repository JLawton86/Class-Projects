#ifndef _CAR_NODE_HPP_
#define _CAR_NODE_HPP_

#include <iostream>
#include <string>
#include "CarRating.hpp"

class CarNode
{
private:
  CarRating _data;
  CarNode *_next;
public:
  CarNode(): _data(), _next(NULL) {}
  CarNode(const CarRating &sval): _data(sval), _next(NULL) {}

  // accessors
  const CarRating& data() const {return _data;}
  CarNode* next() const {return _next;}

  // modifiers
  CarRating& data() {return _data;}
  CarNode* & next() {return _next;}
  
  friend std::ostream& operator<<(std::ostream &os, const CarNode &ln);
  
};

#endif
