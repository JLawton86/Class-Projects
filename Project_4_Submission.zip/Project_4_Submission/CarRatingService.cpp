//cpp file
/************************************************
 * FILE: CarRating.cpp                          *
 * AUTHOR: Jacob Lawton                         *
 * DATE: 3/21/2022                              *
 * Platform Developed on: Linux                 *
 * PURPOSE: Implements CarRatingService class   *
 ************************************************/
#include "CarRatingService.hpp"

using namespace std;

CarNode*
findTail()
{
return NULL; //code later
}
CarNode*
findPrev()
{
return NULL; //code later
}

void
CarRatingService::addFront(const CarRating &newData)
{
  CarNode *newNode;
  newNode = new CarNode(newData);

  bool startedEmpty = (_head==NULL) ;
  
  newNode->next() = _head;

  _head=newNode;

  if (startedEmpty)
    _tail = newNode;
}

void
CarRatingService::append(const CarRating &newData) //add at end of list
{
  CarNode *nodeToAdd = new CarNode(newData);
  CarNode *tail = (*this).findTail();

  // if the tail actually existed ... go ahead and add node ...
  if (tail)
    {
      tail->next() = nodeToAdd;
      _tail = nodeToAdd;
    }
  else // add to an empty list, so adding at front is same as adding at tail
    addFront(newData);
  
}


/*void
CarRatingService::insertBefore(CarNode *here, const CarRating &newData)
{
  // is requested position valid? if not ... 
  if (here==NULL)
    {
      cout << "Invalid position specified for location in insertBefore()"
	   << endl;
      return;
    }

  // are you inserting before head ?
  if (here == _head)
    {
      addFront(newData);
      return;
    }
  
  CarNode *prev = findPrev(here->data());

  CarNode *newNode = new CarNode(newData);

  newNode->next() = here;
  prev->next() = newNode;
}
*/
void
CarRatingService::insertAfter(CarNode *here, const CarRating &newData)
{
  // is requested position valid? if not ... 
  if (here==NULL)
    {
      cout << "Invalid position specified for location in insertAfter()"
	   << endl;
      return;
    }
  
  CarNode* newNode = new CarNode(newData);
  newNode->next() = here->next();
  here->next() = newNode;

  if (_tail->next() != NULL)
    _tail = newNode;
}

// gets information from the input stream
CarRatingService::CarRatingService(istream& _input)
{
	int x = 0;

	//initializes instance variables
	 CarRating nextRating; 	
	_numCars = 0;
	_curr=0;

	// takes the car's information and stores it in a node
	while (_input >> nextRating)
	{
		x++;
		_numCars = x;
		_curr++;

			// if the list needs to increase in size, this code makes sure to keep the previous information stored so it is not lost while appending another node onto the end of the list
			
			CarRating *CarRate = new CarRating;
			
			append(*CarRate);
		
	}
}
// clears the collection of car ratings
void CarRatingService::clear()
{
	_head=NULL;
	_tail=NULL;
	_numCars = 0;
}

//returns the car rating information to be printed
ostream& CarRatingService::print(ostream& toStream) const 
{ 
	CarNode *curr;
	curr=_head;
	while(curr != NULL)
	{
		toStream << curr << endl;
		curr=curr->next();
	}
	
	return toStream; 
}


//prints the car rating information
ostream& operator<<(ostream& os, const CarRatingService& crs)
{
	return crs.print(os);
}
//overloads the += operator to add more car ratings to the list
const CarRatingService& CarRatingService::operator+=(CarRating const& newRating)
{
	//variables to hold information about the car 
	int year;
	string make;
	string model;
	double rating;
	CarNode *curr;

	//sets the information from provided files into more accessible local variables
	year = newRating.year();
	make = newRating.make();
	model = newRating.model();
	rating = newRating.rating();

	//checks if the car information being entered is identical to a previous entry
	curr=_head;
	while (curr!=NULL)
	{
		if (curr->data().year() == year && curr->data().make() == make && curr->data().model() == model)
		{
			//if the entry is identical, the ratings are updated 
			curr->data().addNewRating(rating);
			_curr++;
			return *this;
		}
		curr=curr->next();
	}

	//initializing more instance variables
	_curr++;
	_numCars++;
	//checks again if the list needs to increase in size because everytime we add a new car rating, it needs to append a new node on the end of the list
	(*this).append(newRating);
	return *this;
}
