//cpp file
/************************************************
 * FILE: CarRating.cpp                          *
 * AUTHOR: Jacob Lawton                         *
 * DATE: 3/21/2022                              *
 * Platform Developed on: Windows               *
 * PURPOSE: Implements CarRatingService class   *
 ************************************************/
#include "CarRatingService.hpp"

using namespace std;

// gets information from the input stream
CarRatingService::CarRatingService(istream& _input)
{
	int x = 0;

	//initializes instance variables
	_numCars = 0;
	_clear = "";
	_carTypes = 5;
	arr = new CarRating[5];

	// takes the car's information and stores it in an array
	while (_input >> arr[x])
	{
		x++;
		_numCars = x;
		_curr++;
		if (_curr >= _carTypes)
		{
			// if the array needs to increase in size, this code makes sure to keep the previous information stored so it is not lost while moving to a bigger array
			CarRating *oldarr = new CarRating[_curr];
			for (int f = 0; f < _curr; f++)
			{
				oldarr[f] = arr[f];
			}
			_carTypes = _carTypes * 2;
			arr = new CarRating[_carTypes];
			for (int g = 0; g < _curr; g++)
			{
				arr[g] = oldarr[g];
			}
		}
	}
}
// clears the collection of car ratings
void CarRatingService::clear()
{
	arr = new CarRating[5];
	_numCars = 0;
}

//returns the car rating information to be printed
ostream& CarRatingService::print(ostream& toStream) const 
{ 
	int x=0;
	while(x < _numCars)
	{
		toStream << arr[x] << endl;
		x++;
	}
	
	return toStream; 
}

//prints the car rating information
ostream& operator<<(ostream& os, const CarRatingService& crs)
{
	return crs.print(os);
}

//overloads the += operator to add more car ratings to the list
const CarRatingService& CarRatingService::operator+=(CarRating const& newRating)
{
	//variables to hold information about the car 
	int x = 0;
	int year;
	string make;
	string model;

	//sets the information from provided files into more accessible local variables
	year = newRating.year();
	make = newRating.make();
	model = newRating.model();

	//checks if the car information being entered is identical to a previous entry
	while (x < _curr)
	{
		if (arr[x].year() == year && arr[x].make() == make && arr[x].model() == model)
		{
			//if the entry is identical, the ratings are updated 
			arr[x] += newRating.rating();
			return *this;
		}
		x++;
	}

	//initializing more instance variables
	arr[_curr] = newRating;
	_curr++;
	_numCars = _curr;
	//checks again if the array needs to increase in size because everytime we add a new car rating, it could go over the max size of the current array
	if (_curr >= _carTypes)
	{
		CarRating* oldarr = new CarRating[_curr];
		for (int f = 0; f < _curr; f++)
		{
			oldarr[f] = arr[f];
		}
		_carTypes = _carTypes * 2;
		arr = new CarRating[_carTypes];
		for (int g = 0; g < _curr; g++)
		{
			arr[g] = oldarr[g];
		}
	}
	return *this;
}