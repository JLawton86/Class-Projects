//hpp file
/***************************************************
 * FILE: CarRatingService.hpp                      *
 * AUTHOR: Jacob Lawton                            *
 * DATE: 3/21/2022                                 *
 * Platform Developed on: Windows                  *
 * PURPOSE: Header file for CarRatingService class *
 *   This class describes a car and a rating       *
 *   for that car.                                 *
 ***************************************************/
#ifndef _CAR_RATING_Service_HPP_
#define _CAR_RATING_Service_HPP_

#include <iostream>
#include <string>
#include "CarRating.hpp"

using namespace std;

class CarRatingService
{
private:
    int _numCars; //number of different types of cars in CarRatingService
    string _clear; //empties the collection so it appears that there are no CarRatings
    int _carTypes; //max amount of possible cars in the collection, can be increased to fit the amount of cars
    int _curr; // current amount of cars in the collection
    CarRating *arr; //array for car ratings
public:
    // default constructor
    CarRatingService() :
        _numCars(0), _clear("N/A"), _carTypes(5), _curr(0)
    {
        arr = new CarRating[5];
    }

    //method for input stream
    CarRatingService(istream& _input);

        //accessor methods
        int numCars() const { return _numCars;}
        void clear();

    //overloaded operator for printing
    ostream& print(ostream& toStream) const;

    //overloads operator for output
    friend ostream& operator<<(ostream& os, const CarRatingService& crs);

    //overloading first += operator
    const CarRatingService& operator+=(CarRating const &newRating);

};
#endif
